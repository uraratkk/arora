function [ e , W1,W2, iter ] = trainMLP( D, label,n_hidden )

iter = 1;
lr1 = 0.02; %learning rate
lr2 = 0.3; 
W1 = rand(n_hidden,size(D,2));
W2 = rand(2,n_hidden);

error_per_iter = 100;
error_max = 10;
error = [];
e =[];
while error_per_iter > error_max & iter < 1000
    
    %Ephoc => iteration
    i_data = randperm(size(D,1))';
    ircorrect = 0;
    for i = 1:size(D,1)
        S = D(i_data(i),:)'; %Sample
        
        %Hidden Layer
        V = W1*S;
        H = logistic(V);
        
        %Output 
        V = W2*H;
        O = logistic(V);
        
        %Gradient (G)
        desired = zeros(2,1);
        desired(label(i_data(i))) = 1;
        error = desired - O;
        
        %G Output
        G_O = error.*O.*(1-O);
        %G Hidden
        G_H = W2'*error.*H.*(1-H);
        
        W2 = W2 + lr2 * G_O * H';
        W1 = W1 + lr1 * G_H * S';
        
        clear max
        [maxValue,index] = max(O);
        
        if index ~= label(i_data(i))
             ircorrect =  ircorrect + 1;
        end
    end
    error_per_iter = ircorrect/size(D,1)*100; % show error after ephoc
    e = [e error_per_iter];
    
    iter = iter+1;
end


end

