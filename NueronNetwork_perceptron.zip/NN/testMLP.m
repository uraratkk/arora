function [ error ] = testMLP( D, label,W,U )


error = 100;

    num_error = 0;
    for i = 1:size(D,1)
        S = D(i,:)'; %Sample
        
        %Hidden Layer
        V = W*S;
        H = logistic(V);
        
        %Output 
        V = U*H;
        O = logistic(V);
        
        %Gradient (G)
        desired = zeros(2,1);
        desired(label(i)) = 1;
       

        clear max
        [maxValue,index] = max(O);
        
        if index ~= label(i)
             num_error =  num_error + 1;
        end
    end
    error = num_error/size(D,1)*100; % show error after ephoc
    

end

