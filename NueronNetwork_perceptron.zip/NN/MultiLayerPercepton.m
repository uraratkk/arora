
close all;
clear all;
load('TicToe.mat')
label = (label(:,1) == 'p')+1;
%label = double(label);
% x = 1, o = 2, b = 3
temp = zeros(size(data,1) , size(data,2));
temp(data == 'x') = 1;
temp(data == 'o') = 2;
temp(data == 'b') = 3;
data_new = temp;

%% normalized
minX = min(min(data_new));
maxX = max(max(data_new));
D = (data_new - minX(1))./(maxX(1) - minX(1));

%% Add biase
D = [D ones(size(D,1),1)];
    
%%
index = randperm(size(D,1))';
range = ceil(size(D,1)/10);

for i=1 :range: size(D,1)
   %% cross-validation 
    if size(D,1) - i < range
        train = D(index(1:i-1),:);
        train_label = label(index(1:i-1),:);

        test = D(index(i:end),:);
        test_label = label(index(i:end),:);
    else
        train = D(index([1:i-1 i+range:end]),:);
        train_label = label(index([1:i-1 i+range:end]),:);

        test = D(index(i:i+range-1),:);
        test_label = label(index(i:i+range-1),:);
    end
    
    [ error , w_hidden ,w_output, iter ] = trainMLP( train, train_label,3 );
    [ error2 ] = testMLP( test, test_label,w_hidden,w_output );
    
    clear min
    min_error = min(error)
    figure,plot(error);
    
end