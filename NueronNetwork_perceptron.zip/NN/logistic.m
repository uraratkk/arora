function [ Y ] = logistic( V )
Y = 1./(1 + exp(-V));
end

